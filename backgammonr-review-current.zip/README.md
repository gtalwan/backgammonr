# backgammonr

`backgammonr` is a computational-statistics package for studying **finite-budget
Monte Carlo allocation** in backgammon, with **Thompson sampling** as the
central method.

The package is not trying to solve backgammon strategy in the expert sense.
Its core scientific object is a local rollout-allocation problem:

- one board state;
- one realized roll;
- `K` legal root moves;
- a finite simulation budget;
- a rule for allocating that budget across moves.

## Scientific Positioning

The package distinguishes three objects explicitly:

1. `rollout-model value`
   the expected reward of a move under the declared continuation policy,
   truncation rule, and payoff mapping;
2. `proxy truth`
   a high-budget Monte Carlo approximation to that rollout-model value;
3. `true backgammon strength / game-theoretic truth`
   unavailable and not claimed by package outputs.

In the canonical benchmark setting, continuation play is random legal play.
That makes the main estimand:

> expected move value under random continuation play, estimated by high-budget
> Monte Carlo.

## Main Workflow

```r
library(backgammonr)

problem <- bg_problem(
  state = bg_initial_board(),
  roll = bg_roll(1L, 6L),
  simulation_policy = "random",
  reward_model = "scalar_payoff",
  posterior_model = "beta_pseudo"
)

truth <- bg_truth_state(
  problem = problem,
  budget = 4096L,
  n_cores = 12L,
  cache = TRUE,
  seed = 1L
)

fit <- bg_ts_run(
  problem = problem,
  budget = 256L,
  proxy_reference = truth$reference,
  seed = 1L
)

cmp <- bg_compare_algorithms(
  problems = problem,
  methods = c("thompson", "top_two_thompson", "ucb", "equal"),
  budgets = c(32L, 64L, 128L, 256L),
  seeds = 1:50,
  proxy_references = truth$reference
)
```

## Main User-Facing Functions

### Truth / Reference

- `bg_truth_state()`
- `bg_truth_opening()`
- `bg_truth_battery()`
- `bg_truth_save()`
- `bg_truth_load()`
- `bg_truth_diagnostics()`

### Thompson Sampling

- `bg_ts_run()`
- `bg_ts_trace()`
- `bg_ts_profile()`
- `bg_ts_seed_sweep()`
- `bg_ttts_run()`
- `bg_ts_variant_run()`
- `bg_ts_posterior_summary()`

### UCB / Other Methods

- `bg_ucb_run()`
- `bg_ucb_profile()`
- `bg_uniform_run()`
- `bg_ocba_run()`
- `bg_compare_algorithms()`

### Model Comparisons

- `bg_compare_posteriors()`
- `bg_compare_reward_models()`

### Evaluation

- `bg_eval_top1()`
- `bg_eval_simple_regret()`
- `bg_eval_rank()`
- `bg_eval_topk()`
- `bg_eval_pairwise()`
- `bg_eval_allocation()`
- `bg_eval_gap_aware()`
- `bg_eval_seed_stability()`
- `bg_eval_reference_aware()`

### State Analysis

- `bg_board_features()`
- `bg_move_features()`
- `bg_state_classify()`
- `bg_state_difficulty()`
- `bg_state_battery()`

### Visualization

- `plot_bg_truth()`
- `plot_bg_gap()`
- `plot_bg_ts_trace()`
- `plot_bg_ucb_trace()`
- `plot_bg_allocation()`
- `plot_bg_budget_curve()`
- `plot_bg_posterior_compare()`
- `plot_bg_rank_compare()`
- `plot_bg_runtime_compare()`
- `plot_bg_seed_variability()`
- `plot_bg_state_battery()`
- `plot_bg_runtime_scaling()`

## Explicit Statistical Model

The package now exposes a real reward/posterior model layer with compatibility
checks.

Current reward models:

- `scalar_payoff`
- `categorical_outcome`
- `win_loss`
- `win_indicator` as a legacy alias only

Current posterior models:

- `beta_pseudo`
- `student_t_marginal`
- `dirichlet_multinomial`
- `beta_bernoulli`
- `bootstrap`
- secondary baselines `gaussian_approx` and `normal_inverse_gamma`

The main stacks worth teaching and comparing are:

- `scalar_payoff + beta_pseudo`
- `scalar_payoff + student_t_marginal`
- `categorical_outcome + dirichlet_multinomial`
- `win_loss + beta_bernoulli`

`win_indicator + beta_bernoulli` remains only as a backward-compatibility
alias. It resolves internally to `scalar_payoff + beta_pseudo` and should not
be treated as the recommended front-door model.

## Sequential Vignette System

The vignette suite is intentionally sequential:

1. define the scientific identity and domain structure;
2. set up parallelism, caching, and reproducibility;
3. build and save proxy truths early;
4. analyze the opening-truth battery in several smaller result chapters;
5. build TS-only, TTTS-only, and comparator studies against that fixed truth;
6. load saved objects in later analytical vignettes;
7. expand to broader state batteries, hardness analysis, CRN, and runtime.

This keeps expensive Monte Carlo work early and reusable.

In practice, the opening workflow should be presented in three blocks:

1. compute and cache the full 21-roll opening truth battery;
2. inspect that truth battery through several smaller result chapters;
3. compute TS-only, TTTS-only, and comparator studies, then analyze them in
   separate chapters.

Heavy compute chapters use the `BGR_HEAVY` gate:

```r
Sys.setenv(BGR_HEAVY = "true")
```

## Installation

From a local checkout:

```r
install.packages(".", repos = NULL, type = "source")
library(backgammonr)
```

For interactive development:

```r
devtools::load_all()
```
