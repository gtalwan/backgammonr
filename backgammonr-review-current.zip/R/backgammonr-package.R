#' backgammonr: Thompson sampling for finite-budget backgammon decisions
#'
#' `backgammonr` is a Thompson-sampling research toolkit for fixed-budget
#' best-action identification under Monte Carlo noise, with backgammon as the
#' stochastic laboratory rather than the primary product identity.
#'
#' The canonical package object is one local decision problem:
#'
#' - one board state;
#' - one realized dice roll;
#' - `K` legal root actions;
#' - rollout-model values `mu_i = E[Y_i | simulation_policy, truncation_rule,
#'   payoff_mapping]`;
#' - a fixed simulation budget `N`;
#' - an allocation policy that decides how to spend that budget.
#'
#' In package terms, a *rollout* is one simulated continuation after committing
#' to a root action. Sequential Thompson sampling is the canonical allocation
#' policy for this budgeted ranking-and-selection problem. Comparator methods
#' remain available, but primarily to help interpret Thompson behavior.
#'
#' @section Scientific distinctions:
#' The package explicitly distinguishes:
#'
#' - rollout-model value: the estimand defined by the rollout continuation
#'   policy, truncation rule, and payoff mapping;
#' - proxy reference: a high-budget Monte Carlo estimate used as a practical
#'   reference for regret and ranking diagnostics;
#' - true backgammon strength / game-theoretic truth: not available and never
#'   implied by the package outputs.
#'
#' Posterior quantities are therefore approximate and model-relative, not claims
#' of exact truth.
#'
#' The package now exposes an explicit reward/posterior model layer. The
#' default front door is the scalar-payoff baseline
#' `reward_model = "scalar_payoff"` with `posterior_model = "beta_pseudo"`,
#' while coherent alternatives such as `win_loss + beta_bernoulli` and
#' `categorical_outcome + dirichlet_multinomial` are available for direct
#' comparison.
#'
#' @section TS-first workflow:
#' Recommended entry points for the new public interface are:
#'
#' - `bg_problem()` to define one state-plus-roll decision problem;
#' - `bg_truth_state()` and `bg_truth_opening()` to build cached proxy
#'   references early in the workflow;
#' - `bg_study_save()` / `bg_study_load()` to keep expensive study objects
#'   reusable across sequential vignettes;
#' - `bg_ts_decide()` to run canonical sequential Thompson sampling on that
#'   problem;
#' - `bg_ts_run()`, `bg_ts_trace()`, and `bg_ts_posterior_summary()` for the
#'   main TS analysis loop;
#' - `bg_reference()` to construct or extend a high-budget proxy reference;
#' - `bg_ts_profile()` to study Thompson behavior over budgets and seeds;
#' - `bg_ucb_run()` / `bg_ucb_profile()` to expose optimism-based comparators;
#' - `bg_compare_algorithms()` to compare Thompson to TTTS, UCB, and baseline
#'   allocation rules;
#' - `bg_eval_reference_aware()` and `plot_bg_budget_curve()` to summarize
#'   finite-budget performance;
#' - `bg_opening_study()` and `bg_state_battery()` for flagship research
#'   workflows.
#'
#' Legacy helpers remain in the source tree for compatibility and transition,
#' but they are no longer the package narrative. The intended workflow runs
#' through the curated `bg_*` interface and the staged vignette sequence.
#'
#' Core loops use `Rcpp`, `RcppArmadillo`, and `RcppParallel` to keep canonical
#' sequential Thompson semantics intact while accelerating proxy-reference
#' generation and repeated-study workflows.
#'
#' @keywords internal
#' @useDynLib backgammonr, .registration = TRUE
#' @importFrom Rcpp evalCpp
"_PACKAGE"
