test_that("TS-first front door builds coherent one-problem objects", {
  problem <- bg_problem(
    state = bg_initial_board(),
    roll = bg_roll(1L, 6L),
    simulation_policy = "random",
    reward_model = "win_indicator",
    posterior_model = "beta_bernoulli",
    cache = FALSE,
    problem_id = "init_1_6"
  )

  expect_s3_class(problem, "bg_problem")
  expect_identical(problem$settings$reward_model, "win_indicator")
  expect_identical(problem$settings$posterior_model, "beta_bernoulli")
  expect_true(nrow(problem$candidate_table) >= 1L)
  expect_equal(nrow(tibble::as_tibble(problem)), nrow(problem$candidate_table))
  expect_s3_class(ggplot2::autoplot(problem), "ggplot")

  fit1 <- bg_ts_decide(problem, budget = 32L, seed = 11L)
  fit2 <- bg_ts_decide(problem, budget = 32L, seed = 11L)

  expect_s3_class(fit1, "bg_ts_run")
  expect_identical(fit1$recommended_index, fit2$recommended_index)
  expect_equal(fit1$action_table$allocation_count, fit2$action_table$allocation_count)
  expect_s3_class(plot_budget_path(fit1), "ggplot")
  expect_s3_class(plot_allocation_flow(fit1), "ggplot")
  expect_s3_class(plot_prob_best(fit1), "ggplot")
  expect_s3_class(ggplot2::autoplot(fit1), "ggplot")
})

test_that("proxy-reference engine is reproducible across worker counts", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)

  ref1 <- bg_reference(
    problem,
    budget = 96L,
    workers_truth = 1L,
    truth_block_size = 16L,
    seed = 17L
  )
  ref2 <- bg_reference(
    problem,
    budget = 96L,
    workers_truth = 2L,
    truth_block_size = 16L,
    seed = 17L
  )

  expect_s3_class(ref1, "bg_reference")
  expect_s3_class(ref2, "bg_reference")
  expect_equal(
    ref1$action_table[, c("candidate_index", "allocation_count", "reward_sum", "reward_sum_sq", "reference_mean")],
    ref2$action_table[, c("candidate_index", "allocation_count", "reward_sum", "reward_sum_sq", "reference_mean")]
  )
  expect_s3_class(ggplot2::autoplot(ref1), "ggplot")
})

test_that("TS profiles, method comparisons, and batched TS smoke-test cleanly", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  ref <- bg_reference(problem, budget = 128L, workers_truth = 2L, truth_block_size = 16L, seed = 19L)

  profile <- bg_ts_profile(
    problem,
    budgets = c(16L, 32L),
    seeds = 1:3,
    proxy_reference = ref,
    n_cores = 2L,
    parallel = TRUE
  )
  compare <- bg_compare_methods(
    problem,
    methods = c("thompson", "top_two_thompson", "ucb", "equal"),
    budgets = c(16L, 32L),
    seeds = 1:3,
    proxy_references = ref,
    n_cores = 2L,
    parallel = TRUE
  )
  ucb <- bg_ucb_run(
    problem,
    budget = 32L,
    checkpoints = c(8L, 16L, 32L),
    proxy_reference = ref,
    seed = 29L
  )
  ucb_profile <- bg_ucb_profile(
    problem,
    budgets = c(16L, 32L),
    seeds = 1:3,
    proxy_reference = ref,
    n_cores = 2L,
    parallel = TRUE
  )
  variant <- bg_ts_variant_run(problem, budget = 32L, variant = "top_two_thompson", proxy_reference = ref, seed = 31L)
  batched <- bg_ts_decide(
    problem,
    budget = 32L,
    ts_mode = "batched",
    batch_size = 4L,
    seed = 23L
  )

  expect_s3_class(profile, "bg_ts_profile")
  expect_s3_class(compare, "bg_method_compare")
  expect_s3_class(ucb, "bg_ts_run")
  expect_true(inherits(ucb_profile, "bg_ucb_profile"))
  expect_s3_class(variant, "bg_ts_run")
  expect_identical(ucb$allocation_policy, "ucb")
  expect_identical(variant$allocation_policy, "top_two_thompson")
  expect_s3_class(batched, "bg_ts_run")
  expect_identical(batched$ts_mode, "batched")
  expect_s3_class(plot_budget_path(profile), "ggplot")
  expect_s3_class(plot_seed_heatmap(profile), "ggplot")
  expect_s3_class(plot_budget_path(compare), "ggplot")
  expect_s3_class(plot_seed_heatmap(compare), "ggplot")
  expect_s3_class(plot_bg_ucb_trace(ucb, metric = "selection_score"), "ggplot")
})

test_that("experimental Thompson variants are compare-ready on the current engine", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  ref <- bg_reference(problem, budget = 64L, workers_truth = 1L, truth_block_size = 8L, seed = 23L)
  variants <- c(
    "thompson",
    "top_two_thompson",
    "multi_sample_thompson",
    "tempered_thompson",
    "budget_aware_thompson",
    "elimination_thompson",
    "ranking_aware_thompson"
  )

  fits <- lapply(
    variants,
    function(v) {
      bg_ts_variant_run(
        problem = problem,
        budget = 16L,
        variant = v,
        proxy_reference = ref,
        checkpoints = c(4L, 8L, 16L),
        seed = 29L
      )
    }
  )
  names(fits) <- variants

  expect_true(all(vapply(fits, inherits, logical(1L), what = "bg_ts_run")))
  expect_equal(unname(vapply(fits, function(x) sum(x$action_table$allocation_count), numeric(1L))), rep(16, length(variants)))
  expect_identical(fits[["multi_sample_thompson"]]$allocation_policy, "multi_sample_thompson")
  expect_identical(fits[["budget_aware_thompson"]]$allocation_policy, "budget_aware_thompson")
  expect_true(all(c("eligible", "eliminated_at") %in% names(fits[["elimination_thompson"]]$action_table)))
  expect_s3_class(plot_bg_ts_trace(fits[["ranking_aware_thompson"]], metric = "estimate"), "ggplot")

  compare <- bg_compare_algorithms(
    problem,
    methods = c(variants, "ucb", "equal"),
    budgets = c(8L, 16L),
    seeds = 1:2,
    proxy_references = ref,
    n_cores = 1L,
    parallel = FALSE,
    progress = FALSE
  )
  expect_s3_class(compare, "bg_method_compare")
  expect_true(all(c(variants, "ucb", "equal") %in% compare$summary$method))
})

test_that("opening, game-trace, and structure studies expose TS-first workflows", {
  opening_rolls <- backgammonr:::bg_opening_roll_grid()
  expect_length(opening_rolls, 21L)
  expect_equal(sum(vapply(opening_rolls, function(x) isTRUE(x$is_double), logical(1L))), 6L)
  expect_length(backgammonr:::bg_opening_roll_grid(include_doubles = FALSE), 15L)

  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)

  opening <- bg_opening_study(
    budgets = 8L,
    seeds = 1L,
    methods = c("thompson", "equal"),
    reference_budget = 32L,
    workers_truth = 2L,
    n_cores = 2L,
    parallel = TRUE,
    truth_block_size = 8L,
    cache = FALSE,
    verbose = FALSE
  )
  trace_fit <- bg_game_trace(
    problems = list(problem, problem, problem, problem),
    local_budget = 8L,
    seeds = 1:2,
    n_reference_nodes = 2L,
    reference_budget = 32L
  )
  structure_fit <- bg_structure_study(
    problems = rep(list(problem), 4L),
    budget = 8L,
    seeds = 1:2,
    reference_budget = 32L
  )

  expect_s3_class(opening, "bg_opening_study")
  expect_s3_class(opening$truth, "bg_truth_battery")
  expect_true(all(c("opening_roll", "is_double", "roll_group") %in% names(opening$difficulty_table)))
  expect_true(all(c("opening_roll", "roll_group", "spearman", "top_k_overlap") %in% names(opening$metric_panel)))
  expect_s3_class(trace_fit, "bg_game_trace")
  expect_s3_class(structure_fit, "bg_structure_study")
  expect_s3_class(plot_opening_atlas(opening), "ggplot")
  expect_s3_class(plot_game_trace(trace_fit), "ggplot")
  expect_s3_class(plot_structure_map(structure_fit), "ggplot")
})

test_that("TS-first front door handles positions with no legal moves", {
  points <- integer(24)
  points[24] <- -2L
  points[23] <- -2L
  points[1] <- -11L
  board <- bg_board(
    points = points,
    bar = c(1L, 0L),
    off = c(14L, 0L),
    turn = 1L
  )
  roll <- bg_roll(1L, 2L)

  problem <- bg_problem(board, roll, cache = FALSE, problem_id = "no_move")
  fit <- bg_ts_decide(problem, budget = 16L, seed = 31L)
  ref <- bg_reference(problem, budget = 32L, seed = 33L)

  expect_length(problem$legal_moves, 0L)
  expect_equal(nrow(problem$candidate_table), 0L)
  expect_s3_class(fit, "bg_ts_run")
  expect_equal(nrow(fit$action_table), 0L)
  expect_true(all(is.na(fit$checkpoint_table$recommended_index)))
  expect_s3_class(ref, "bg_reference")
  expect_equal(nrow(ref$action_table), 0L)
  expect_true(is.na(ref$summary$proxy_reference_best_index[[1L]]))
})
