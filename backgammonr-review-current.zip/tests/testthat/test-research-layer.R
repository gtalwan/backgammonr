test_that("truth workflows save, load, and summarize coherently", {
  problem <- bg_problem(
    state = bg_initial_board(),
    roll = bg_roll(1L, 6L),
    cache = FALSE,
    problem_id = "truth_case"
  )

  path <- tempfile(fileext = ".rds")
  truth <- bg_truth_state(
    problem = problem,
    budget = 64L,
    n_cores = 2L,
    parallel = TRUE,
    save_path = path,
    overwrite = TRUE,
    seed = 9L
  )

  expect_s3_class(truth, "bg_truth_state")
  expect_true(file.exists(path))
  expect_equal(truth$reference$summary$reference_budget[[1L]], 64L)

  truth2 <- bg_truth_load(path)
  expect_s3_class(truth2, "bg_truth_state")
  expect_identical(truth$metadata$problem_hash, truth2$metadata$problem_hash)

  diag <- bg_truth_diagnostics(truth)
  expect_true(all(c("summary", "move_table") %in% names(diag)))
  expect_true("top_two_gap_estimate" %in% names(diag$summary))

  opening <- bg_truth_opening(
    rolls = list(bg_roll(1L, 6L), bg_roll(2L, 4L)),
    budget = 32L,
    n_cores = 2L,
    cache = FALSE,
    verbose = FALSE,
    seed = 5L
  )

  expect_s3_class(opening, "bg_truth_battery")
  expect_equal(nrow(opening$summary), 2L)
  expect_true("opening_roll" %in% names(opening$summary))
  expect_true(all(c("die1", "die2", "is_double", "roll_group") %in% names(opening$summary)))

  opening_path <- tempfile(fileext = ".rds")
  opening_saved <- bg_truth_opening(
    rolls = list(bg_roll(1L, 1L), bg_roll(1L, 2L)),
    budget = 16L,
    n_cores = 2L,
    cache = FALSE,
    save_path = opening_path,
    overwrite = TRUE,
    verbose = FALSE,
    seed = 6L
  )
  opening_loaded <- bg_truth_load(opening_path)
  expect_equal(names(opening_saved$summary), names(opening_loaded$summary))
  expect_true(all(c("opening_roll", "is_double") %in% names(opening_loaded$summary)))
})

test_that("research wrappers and evaluation helpers return interpretable outputs", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  truth <- bg_truth_state(problem = problem, budget = 64L, n_cores = 2L, cache = FALSE, seed = 1L)

  ts_run <- bg_ts_run(problem, budget = 32L, proxy_reference = truth$reference, seed = 2L)
  ts_fit <- bg_ts_trace(problem, budget = 32L, proxy_reference = truth$reference, seed = 2L)
  ttts_fit <- bg_ttts_run(problem, budget = 32L, proxy_reference = truth$reference, seed = 2L)
  ucb_fit <- bg_ucb_run(problem, budget = 32L, checkpoints = c(8L, 16L, 32L), proxy_reference = truth$reference, seed = 2L)
  uniform_fit <- bg_uniform_run(problem, budget = 32L, proxy_reference = truth$reference, seed = 2L)
  ocba_fit <- bg_ocba_run(problem, budget = 32L, proxy_reference = truth$reference, seed = 2L)

  expect_s3_class(ts_run, "bg_ts_run")
  expect_s3_class(ts_fit, "bg_ts_run")
  expect_s3_class(ttts_fit, "bg_ts_run")
  expect_s3_class(ucb_fit, "bg_ts_run")
  expect_s3_class(uniform_fit, "bg_ts_run")
  expect_s3_class(ocba_fit, "bg_ts_run")
  expect_identical(ucb_fit$settings$reward_model, "scalar_payoff")
  expect_identical(ucb_fit$settings$posterior_model, "beta_pseudo")
  expect_identical(ocba_fit$allocation_policy, "ocba")
  expect_true(all(c("move_label", "estimate") %in% names(bg_ts_posterior_summary(ts_run))))
  expect_true(all(c("candidate_index", "move_label", "n_steps") %in% names(bg_move_features(problem))))

  top1 <- bg_eval_top1(ts_fit)
  rank <- bg_eval_rank(ts_fit)
  alloc <- bg_eval_allocation(ts_fit)
  gap <- bg_eval_gap_aware(ts_fit)
  ref_aware <- bg_eval_reference_aware(ts_fit)

  expect_true(all(c("top1_match", "simple_regret", "selected_reference_rank") %in% names(top1)))
  expect_true(all(c("spearman", "kendall", "top_k_overlap") %in% names(rank)))
  expect_true(all(c("share_top_k_truth", "share_dominated") %in% names(alloc)))
  expect_true(all(c("chosen_in_indistinguishable_top_set", "near_tie") %in% names(gap)))
  expect_true(all(c("top1_match", "spearman", "share_top_k_truth", "near_tie") %in% names(ref_aware)))
})

test_that("comparison studies feed budget and seed diagnostics", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  truth <- bg_truth_state(problem = problem, budget = 64L, n_cores = 2L, cache = FALSE, seed = 3L)

  cmp <- bg_compare_algorithms(
    problems = problem,
    methods = c("thompson", "top_two_thompson", "ucb", "equal"),
    budgets = c(16L, 32L),
    seeds = 1:3,
    proxy_references = truth$reference,
    n_cores = 2L,
    parallel = TRUE
  )

  seed_stability <- bg_eval_seed_stability(cmp, metric = "simple_regret")
  topk <- bg_eval_topk(cmp, k = 2L)
  pairwise <- bg_eval_pairwise(cmp)

  expect_s3_class(cmp, "bg_method_compare")
  expect_true(all(c("mean_value", "selection_entropy") %in% names(seed_stability)))
  expect_true(all(c("top_k_overlap", "posterior_top_k_mass") %in% names(topk)))
  expect_true(all(c("pairwise_ordering_accuracy", "pairwise_disagreement_count") %in% names(pairwise)))
})

test_that("state classifiers and state batteries produce structured outputs", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  cls <- bg_state_classify(problem)
  diff <- bg_state_difficulty(problem)

  expect_true(all(c("state_class", "contact", "player_prime_length") %in% names(cls)))
  expect_true(all(c("difficulty_score", "top_two_gap_estimate") %in% names(diff)))

  battery <- bg_state_battery(
    n_games = 2L,
    positions_per_game = 2L,
    max_turns = 8L,
    reference_budget = 32L,
    methods = c("thompson", "equal"),
    budgets = 8L,
    comparison_seeds = 1:2,
    n_cores = 2L,
    cache = FALSE,
    verbose = FALSE,
    seeds = c(10L, 11L)
  )

  expect_s3_class(battery, "bg_state_battery")
  expect_true(nrow(battery$state_table) >= 1L)
  expect_true("state_class" %in% names(battery$state_table))
  expect_s3_class(battery$comparison, "bg_method_compare")
})

test_that("new plot helpers return ggplot objects", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  truth <- bg_truth_state(problem = problem, budget = 64L, n_cores = 2L, cache = FALSE, seed = 4L)
  fit <- bg_ts_decide(problem, budget = 32L, proxy_reference = truth$reference, seed = 4L)
  cmp <- bg_compare_algorithms(
    problems = problem,
    methods = c("thompson", "equal"),
    budgets = c(16L, 32L),
    seeds = 1:2,
    proxy_references = truth$reference
  )
  battery <- bg_state_battery(
    n_games = 1L,
    positions_per_game = 2L,
    max_turns = 6L,
    reference_budget = 32L,
    n_cores = 2L,
    cache = FALSE,
    verbose = FALSE,
    seeds = 12L
  )

  expect_s3_class(plot_bg_truth(truth), "ggplot")
  expect_s3_class(plot_bg_gap(truth), "ggplot")
  expect_s3_class(plot_bg_ts_trace(fit, metric = "allocation"), "ggplot")
  expect_s3_class(plot_bg_ucb_trace(bg_ucb_run(problem, budget = 32L, checkpoints = c(8L, 16L, 32L), proxy_reference = truth$reference, seed = 6L), metric = "selection_score"), "ggplot")
  expect_s3_class(plot_bg_allocation(fit), "ggplot")
  expect_s3_class(plot_bg_budget_curve(cmp, metric = "simple_regret"), "ggplot")
  expect_s3_class(plot_bg_rank_compare(fit), "ggplot")
  expect_s3_class(plot_bg_seed_variability(cmp, metric = "simple_regret"), "ggplot")
  expect_s3_class(plot_bg_state_battery(battery, metric = "class_count"), "ggplot")
  expect_s3_class(plot_bg_runtime_scaling(bg_profile_runtime(bg_initial_board(), bg_roll(1L, 6L), total_budget = 32L, seed = 1L)), "ggplot")
})

test_that("study save/load round-trips through disk", {
  problem <- bg_problem(bg_initial_board(), bg_roll(1L, 6L), cache = FALSE)
  profile <- bg_ts_seed_sweep(
    problem = problem,
    budgets = c(8L, 16L),
    seeds = 1:2,
    n_cores = 2L,
    parallel = TRUE,
    progress = FALSE
  )

  path <- tempfile(fileext = ".rds")
  bg_study_save(profile, path, overwrite = TRUE)
  loaded <- bg_study_load(path)

  expect_s3_class(loaded, "bg_ts_profile")
  expect_equal(length(loaded$runs), length(profile$runs))
})
